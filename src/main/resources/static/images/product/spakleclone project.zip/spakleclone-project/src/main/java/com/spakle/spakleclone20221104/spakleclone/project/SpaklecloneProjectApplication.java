package com.spakle.spakleclone20221104.spakleclone.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpaklecloneProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpaklecloneProjectApplication.class, args);
	}

}
